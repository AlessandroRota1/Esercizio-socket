﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

public class SynchronousSocketListener
{
    public static void StartListening()
    {
        // Buffer per i dati in arrivo
        byte[] bytes = new byte[1024];

        // Creazione del punto finale locale per il server (IP e porta)
        IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
        IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 5000);

        // Creazione di un socket TCP/IP
        Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

        try
        {
            // Binding del socket al punto finale locale e avvio dell'ascolto
            listener.Bind(localEndPoint);
            listener.Listen(10);

            Console.WriteLine("In attesa di una connessione...");

            while (true)
            {
                // Accetta una connessione in entrata
                Socket handler = listener.Accept();
                Console.WriteLine("Connessione accettata da: {0}", handler.RemoteEndPoint.ToString());

                // Ricezione del messaggio dal client (richiesta di generare un numero)
                string data = null;
                int bytesRec = handler.Receive(bytes);
                data = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                if (data == "GeneraNumero")
                {
                    // Generazione del numero casuale
                    Random random = new Random();
                    int numeroGenerato = random.Next(1, 101);

                    // Invia il numero generato al client
                    byte[] msg = Encoding.ASCII.GetBytes(numeroGenerato.ToString());
                    handler.Send(msg);

                    // Mostra il numero generato sul server
                    Console.WriteLine("Numero generato e inviato al client: {0}", numeroGenerato);
                }

                // Chiudi la connessione col client
                handler.Shutdown(SocketShutdown.Both);
                handler.Close();
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Errore: {0}", e.ToString());
        }

        Console.WriteLine("\nPremi INVIO per continuare...");
        Console.ReadLine();
    }

    public static void Main(String[] args)
    {
        // Avvio del server
        StartListening();
    }
}
