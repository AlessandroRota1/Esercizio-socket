﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public partial class Form1 : Form
    {
        private Socket senderSocket;  // Variabile per il socket

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // Metodo per aprire la connessione al server
        private void Open_Client_Click(object sender, EventArgs e)
        {
            try
            {
                // Indirizzo IP e porta del server
                IPAddress ipAddress = System.Net.IPAddress.Parse("127.0.0.1");
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, 5000);

                // Creazione del socket per connettersi al server
                senderSocket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                // Connessione al server
                senderSocket.Connect(remoteEP);

                MessageBox.Show("Connessione stabilita con il server");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la connessione: " + ex.Message);
            }
        }

        // Metodo per inviare la richiesta di generazione del numero
        private void GeneraNumeroButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (senderSocket != null && senderSocket.Connected)
                {
                    // Invio di una richiesta vuota al server per generare il numero
                    byte[] requestMsg = Encoding.ASCII.GetBytes("GeneraNumero");
                    senderSocket.Send(requestMsg);

                    // Ricezione del numero generato dal server
                    byte[] bytes = new byte[1024];
                    int bytesRec = senderSocket.Receive(bytes);
                    string numeroRicevuto = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                    // Visualizzazione del numero ricevuto nell'interfaccia utente
                    NumeroLabel.Text = "Numero generato dal server: " + numeroRicevuto;
                }
                else
                {
                    MessageBox.Show("Connessione non stabilita. Premi il tasto per aprire la connessione.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la comunicazione col server: " + ex.Message);
            }
        }

        // Metodo per chiudere la connessione al server
        private void Exit_Client_Click(object sender, EventArgs e)
        {
            try
            {
                if (senderSocket != null && senderSocket.Connected)
                {
                    // Chiusura della connessione
                    senderSocket.Shutdown(SocketShutdown.Both);
                    senderSocket.Close();
                    senderSocket = null; // Resetta il socket

                    MessageBox.Show("Connessione chiusa con il server");
                }
                else
                {
                    MessageBox.Show("Nessuna connessione attiva da chiudere.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore durante la chiusura della connessione: " + ex.Message);
            }
        }
    }
}
